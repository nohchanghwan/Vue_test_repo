export const getTodoItems = function(state) {
	return state.todoItems;
}
